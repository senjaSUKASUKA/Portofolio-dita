---
name: Kurasi Studio
colors:
  surface: '#f9f9f7'
  surface-dim: '#dadad8'
  surface-bright: '#f9f9f7'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f2'
  surface-container: '#eeeeec'
  surface-container-high: '#e8e8e6'
  surface-container-highest: '#e2e3e1'
  on-surface: '#1a1c1b'
  on-surface-variant: '#46464b'
  inverse-surface: '#2f3130'
  inverse-on-surface: '#f1f1ef'
  outline: '#76777b'
  outline-variant: '#c7c6cb'
  surface-tint: '#5e5e62'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1f'
  on-primary-container: '#848387'
  inverse-primary: '#c7c6ca'
  secondary: '#4b41e1'
  on-secondary: '#ffffff'
  secondary-container: '#645efb'
  on-secondary-container: '#fffbff'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#0b1c30'
  on-tertiary-container: '#75859d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3e2e6'
  primary-fixed-dim: '#c7c6ca'
  on-primary-fixed: '#1b1b1f'
  on-primary-fixed-variant: '#46464a'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c30'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f9f9f7'
  on-background: '#1a1c1b'
  surface-variant: '#e2e3e1'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 4.5rem
    fontWeight: '600'
    lineHeight: '1.05'
    letterSpacing: -0.035em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.75rem
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '600'
    lineHeight: '1.15'
    letterSpacing: -0.03em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.025em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 2rem
    fontWeight: '500'
    lineHeight: '1.25'
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.65'
    letterSpacing: -0.01em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: -0.005em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: '1.5'
    letterSpacing: '0'
  label-mono:
    fontFamily: JetBrains Mono
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: '1.4'
    letterSpacing: -0.01em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: '1.3'
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-desktop: 2.5rem
  margin: 1.25rem
  margin-desktop: 4rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3.5rem
  space-2xl: 6rem
---

## Brand & Style

This design system embodies an editorial, gallery-grade digital environment designed for senior creatives, digital architects, and design directors operating within contemporary international and Southeast Asian cultural landscapes. The visual identity merges Swiss International Typographic precision with modern architectural minimalism—prioritizing content clarity, structured vertical pacing, and quiet authority.

The experience evokes calm focus, uncompromising craft, and intellectual rigor. Rather than relying on skeuomorphism or loud decorative flourishes, visual interest is created through structural balance, disciplined grid tension, meticulous typographic scales, and high-precision linear borders.

Monospaced accents introduce technical credibility, referencing source metadata, curation registries, and architectural schematics. Indonesian copy context is natively integrated, accommodating distinct word lengths, balanced diacritics, and natural cadences in both bilingual and Indonesian-first editorial contexts (e.g., *Studi Kasus*, *Tentang*, *Arsip Proyek*, *Direktori*).

## Colors

The palette establishes an architectural foundation of warm paper neutrals, deep charcoals, and an assertive single-accent signal.

- **Background Canvas (`#F8F8F6`)**: A calibrated warm alabaster stone that eliminates clinical glare while preserving pure contrast for project imagery.
- **Surface Elevation (`#FFFFFF`)**: Pure crisp white reserved for project cards, floating panels, and focused reading planes.
- **Primary Ink (`#121316`)**: An obsidian charcoal that delivers high-contrast readability without the harshness of pure black (`#000000`).
- **Secondary Accent (`#4F46E5`)**: Electric Indigo. Applied sparingly as an active state indicator, progress beacon, tag highlight, or hyperlink hover. It commands immediate optical priority against the neutral backdrop.
- **Tertiary Slate (`#64748B`)**: Mid-tone technical slate for secondary metadata, project dates, client roles, and monospaced system details.
- **Border Inks (`#E4E4E0` / `#D1D1CB`)**: Low-energy, precise structural lines that define zones, cards, and column demarcations without fragmenting the canvas.

## Typography

Typography governs the composition. The pairings reflect two complementary forces: **Plus Jakarta Sans** provides humanist geometric warmth, high readability, and effortless editorial flow, while **JetBrains Mono** introduces precision engineering, architectural cataloguing, and chronological metadata.

- **Display & Headlines**: Tightly tracked, confident, and intentional. Used for project names, personal declarations, and chapter markers.
- **Body Copy**: Set with open line heights (`1.6`–`1.65`) to maintain high legibility across extended Indonesian case study narratives (*deskripsi proyek, latar belakang masalah, hasil dampak*).
- **Monospaced Accents**: Set in JetBrains Mono in upper and sentence casing for categories, publication dates, client metadata, coordinates, and numbered project indices (`01/`, `[ARSIP]`, `CATALOGUE-2025`).

## Layout & Spacing

The layout utilizes a vertical storytelling rhythm built upon a structured 12-column grid on desktop, a 6-column grid on tablet, and a 4-column system on mobile devices.

### Grid & Margins
- **Desktop (≥ 1280px)**: Max container width constrained to `1200px` for optimal reading scan lines, with outer margins set to `margin-desktop` (`4rem`) and gutters of `2.5rem`.
- **Mobile (< 768px)**: Fluid full-bleed layout with edge margins of `margin` (`1.25rem`) and gutters of `1.5rem`.

### Vertical Storytelling Cadence
Sections advance sequentially as an editorial stream. Structural chapter breaks utilize generous vertical padding (`space-2xl` / `6rem` to `8rem`), allowing each portfolio case study to breathe independently without visual collisions. 

Content hierarchies within a single project showcase are anchored by standard `space-lg` and `space-xl` intervals, guaranteeing that case assets (hero image, context paragraph, role manifest, resolution showcases) maintain clear visual grouping.

## Elevation & Depth

Visual hierarchy rejects traditional dropped blur shadows and fuzzy elevations in favor of clean plane shifts, crisp structural hairline borders, and tactile light contrast.

- **Surface Tiers**:
  - `Base Floor`: The warm canvas (`#F8F8F6`).
  - `Surface 1 (Cards & Modules)`: `#FFFFFF`, framed with a precise 1px border (`#E4E4E0`).
  - `Surface 2 (Floating Navigation & Modals)`: Semi-translucent `#FFFFFF` at 85% opacity with an ultra-subtle backdrop blur (`backdrop-filter: blur(12px)`) and a crisply defined `#121316` (8% opacity) border.
- **Hairline Framing**: Structural separation is achieved through continuous `1px` lines rather than shadows. Hovering over interactive showcase cards transitions border strokes to `#121316` or highlights them with `#4F46E5`.
- **Depth Transitions**: Element states elevate solely through subtle micro-translations (`translateY(-2px)`) and acute border value shifts, preserving an architectural, flat-modernist identity.

## Shapes

The shape vocabulary uses restrained, tight geometry. Micro-radii prevent the visual rigidity of brutalist 0px borders while avoiding generic soft bubbles.

- **Base Radius (`roundedness: 1`)**: Standard elements, buttons, inputs, and chips inherit a tight `0.25rem` (4px) corner radius.
- **Card & Media Frames (`rounded-lg`)**: Visual containers and project showcases use an understated `0.5rem` (8px) corner radius, preserving clean image perimeters.
- **Status Indicator Tokens**: Small technical pills (`badge-pill`) may utilize full circular radii for system state dots and numeric chapter tags.

## Components

### Buttons
- **Primary Action**: Solid obsidian `#121316` background, `#F8F8F6` typography, `0.25rem` radius, padding `0.75rem 1.5rem`. On hover, subtle color translation or background transition to `#4F46E5`.
- **Secondary / Ghost**: Transparent background, 1px solid `#D1D1CB` border, `#121316` text. Monospaced labels are supported for secondary actions (e.g., `LIHAT KODE ->`, `UNDUH CV`).
- **Text Link**: Inline with copy, accompanied by an offset underline or monospaced trailing arrow (`->`), shifting to `#4F46E5` on interaction.

### Chips & Badges
- **Category / Tag**: JetBrains Mono font (`label-mono-sm`), `0.25rem` radius, background `#F0F0EB`, 1px border `#E4E4E0`, text `#121316`. Used for disciplines (*Desain Produk, Tipografi, Sistem Desain*).
- **Status Accent**: Features a live 6px `#4F46E5` circular pulse indicator alongside text (e.g., `TERSEDIA UNTUK PROYEK Q3`).

### Project Showcase Cards
- **Architecture**: Enclosed within a `#FFFFFF` surface with a 1px border `#E4E4E0`. 
- **Header**: Monospaced indexing header (`01 / IDENTITAS`, `2024`) stacked over the primary project title.
- **Media Window**: 16:10 or 4:3 high-resolution viewport with a `0.25rem` image radius and subtle overflow clipping.
- **Footer Metadata**: Clean horizontal key-value summary list (e.g., *Klien*, *Peran*, *Tahun*).

### Lists & Project Archives
- **Linear Archive Row**: Border-bottom separated table-like rows (`1px solid #E4E4E0`) showcasing project index, title, client, discipline, and external arrow indicator. Expands or highlights with `#F8F8F6` background fill on hover.

### Form Inputs (Contact & Inquiries)
- **Field Base**: Background `#FFFFFF`, 1px border `#D1D1CB`, `0.25rem` corner radius, internal padding `0.875rem 1rem`. Focus state shifts border color immediately to `#4F46E5` with zero outer shadow blur. Monospaced placeholder labels (*contoh: nama@domain.id*).

### Sticky Navigation Header
- **Minimal Bar**: Centered or justified single-line nav using a frosted background surface, fixed height of 64px, featuring logo mark, bilingual locale switch (`ID / EN`), and vertical chapter indicators.